const api = typeof browser !== 'undefined' ? browser : chrome;
const stationsNode = document.getElementById('stations');
const stopButton = document.getElementById('stop');
const statusNode = document.getElementById('status');
const nowplayingNode = document.getElementById('nowplaying');
const refreshButton = document.getElementById('refresh');
const popoutButton = document.getElementById('popout');
const versionNode = document.getElementById('version');

const params = new URLSearchParams(window.location.search);
const isPopout = params.get('mode') === 'popout';

function storageGetLocal(keys) {
  if (typeof browser !== 'undefined') {
    return browser.storage.local.get(keys);
  }
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSetLocal(values) {
  if (typeof browser !== 'undefined') {
    return browser.storage.local.set(values);
  }
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}
const changelogOverlay = document.getElementById('changelog');
const changelogBody = document.getElementById('changelog-body');
const changelogClose = document.getElementById('changelog-close');

// Changelog shown when the version badge is clicked (newest first, SemVer).
const CHANGELOG = [
  { version: '0.4.8', date: '2026-09-30', changes: ['Nouvelle version versionnée pour mise en production.', 'Centralisation des données des stations dans shared/stations.json.'] },
  { version: '0.4.7', date: '2026-09-08', changes: ['Fini les sons superposés : la sidebar et la fenêtre détachée ne peuvent plus jouer en même temps, et « Arrêter » coupe la radio où qu’elle joue.', 'Le bouton « Rafraîchir » ne relance plus une radio que vous venez d’arrêter (ou de changer) pendant le chargement.', 'Un flux qui se termine ou se coupe n’affiche plus « en lecture » : l’interface et le badge repassent à l’arrêt.'] },
  { version: '0.4.6', date: '2026-07-30', changes: ['La zone « en lecture » affiche un état par défaut discret (« Aucune radio en lecture ») au lieu d’un espace vide.'] },
  { version: '0.4.5', date: '2026-07-30', changes: ['Plus de saut de mise en page (CLS) au lancement d’une radio : la zone « en lecture » est désormais réservée en permanence, les tuiles ne bougent plus.'] },
  { version: '0.4.4', date: '2026-07-30', changes: ['Le bouton « Rafraîchir » a maintenant un effet visible : il reconnecte le flux en cours (utile si le son se fige), re-trie la liste par écoutes et l’icône tourne le temps de l’opération.'] },
  { version: '0.4.3', date: '2026-07-30', changes: ['Le bouton « Détacher » ne crée plus de doublons : s’il existe déjà une fenêtre, un nouveau clic la ramène au premier plan.', 'La fenêtre détachée est entièrement redimensionnable : le contenu remplit toute la fenêtre et la grille ajuste ses colonnes.'] },
  { version: '0.4.2', date: '2026-07-30', changes: ['Flux France Inter, franceinfo, Europe 1, RFM et Chante France pointés directement sur leur hôte final (une redirection en moins à chaque lecture ; Chante France passe en HTTPS).'] },
  { version: '0.4.1', date: '2026-07-30', changes: ['Correctif perf : l’arrêt coupe réellement le flux (fini le téléchargement en arrière-plan et les connexions qui s’empilaient à chaque relance).', 'Icônes « Détacher » et « Rafraîchir » alignées sur le toolkit.'] },
  { version: '0.4.0', date: '2026-07-30', changes: ['Nouveau bouton « Détacher » : ouvre le lecteur dans une fenêtre séparée pour continuer l’écoute même en fermant la sidebar (la station en cours est reprise).'] },
  { version: '0.3.10', date: '2026-07-30', changes: ['Bouton « Arrêter » plus lisible (icône + libellé, contraste renforcé) et contrastes de l’en-tête ajustés (accessibilité).'] },
  { version: '0.3.9', date: '2026-07-30', changes: ['Haut de la sidebar optimisé : titre en double retiré, et le bouton d’arrêt n’apparaît plus que pendant la lecture (barre « en lecture » compacte).'] },
  { version: '0.3.8', date: '2026-07-30', changes: ['En-tête épuré : titre, description et version regroupés sur une ligne.'] },
  { version: '0.3.7', date: '2026-07-30', changes: ['Numéro de version déplacé dans l’en-tête, cliquable pour afficher les nouveautés.'] },
  { version: '0.3.6', date: '2026-07-30', changes: ['Classement par usage rétabli : les radios les plus écoutées remontent en tête.'] },
  { version: '0.3.5', date: '2026-07-30', changes: ['Bouton rafraîchir dans la barre d’outils.', 'Version affichée lue depuis le manifest.'] },
  { version: '0.3.4', date: '2026-07-30', changes: ['Manifest Firefox conforme à la validation Mozilla (AMO).'] },
  { version: '0.3.3', date: '2026-07-30', changes: ['Badge « ON » sur l’icône pendant la lecture.', 'Station en cours de lecture bien plus visible.'] },
  { version: '0.3.2', date: '2026-07-30', changes: ['Lien « Site » de nouveau visible sous chaque station.'] },
  { version: '0.3.1', date: '2026-07-30', changes: ['Correction de 4 flux : RTL, RTL2, Fun Radio, RFM.'] },
  { version: '0.3.0', date: '2026-07-26', changes: ['Lecture depuis la sidebar avec surveillance du flux.'] }
];

let audio = null;
let stations = [];
let currentStationId = null;
let status = 'stopped';

// Playback happens locally in each context: the sidebar and the detached
// window each own an <audio>. Nothing in the browser arbitrates between them,
// so the contexts elect a single owner by broadcasting every playback change
// over runtime messaging. Broadcasts only reach *live* contexts (unlike a
// record in storage, which can outlive the window that wrote it), so a closed
// pop-out can never leave a phantom "playing" state behind.
const CONTEXT_ID = 'ctx-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
let playbackOwner = null;

// Bumped by every change of playback intent (local or remote). Async work that
// wants to resume playback captures it first and gives up if it moved, so a
// slow request can never resurrect a stream the user has since stopped.
let playbackGeneration = 0;

function announcePlayback() {
  sendMessage({
    type: 'SIDEBAR_PLAYBACK',
    ownerId: CONTEXT_ID,
    status: status,
    stationId: currentStationId
  }).catch(() => {});
}

// Another context took over (or stopped) playback: release our own audio so
// only one stream is ever audible, and mirror its state so the tiles, the
// status line and the badge stay truthful in every window.
function adoptRemotePlayback(message) {
  playbackGeneration += 1;
  teardownAudio();

  const stopped = !message.status || message.status === 'stopped';
  playbackOwner = stopped ? null : message.ownerId;
  status = stopped ? 'stopped' : message.status;
  currentStationId = stopped ? null : (message.stationId || null);
  renderPlaybackState();
}

if (api.runtime && api.runtime.onMessage) {
  api.runtime.onMessage.addListener((message) => {
    if (!message || message.ownerId === CONTEXT_ID) {
      return;
    }

    if (message.type === 'SIDEBAR_PLAYBACK') {
      adoptRemotePlayback(message);
      return;
    }

    // A newly opened context asks who is playing; only the owner answers.
    if (message.type === 'SIDEBAR_PLAYBACK_QUERY' && playbackOwner === CONTEXT_ID && status !== 'stopped') {
      announcePlayback();
    }
  });
}

function sendMessage(message) {
  if (typeof browser !== 'undefined') {
    return browser.runtime.sendMessage(message);
  }

  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }

      resolve(response);
    });
  });
}

function setStatus(message) {
  statusNode.textContent = message || '';
}

// Toolbar icon badge: an "ON" chip while a station plays. Playback happens
// locally in the sidebar, so the badge is driven from here rather than the
// background service worker.
function setActionBadge(text, color) {
  if (!api.action || typeof api.action.setBadgeText !== 'function') {
    return;
  }
  try {
    api.action.setBadgeText({ text: text });
    api.action.setBadgeBackgroundColor({ color: color });
  } catch (error) {
    /* action badge API unavailable in this context */
  }
}

// Fully release the current <audio> element AND abort its network request.
// pause() + removeAttribute('src') alone does NOT stop the ongoing download —
// the media element keeps buffering until load() runs its resource-reset
// algorithm. We also detach listeners so a stale element can't drive the UI.
function teardownAudio() {
  if (!audio) {
    return;
  }
  const el = audio;
  audio = null;
  el.onplaying = null;
  el.onerror = null;
  el.onended = null;
  el.onpause = null;
  try {
    el.pause();
  } catch (error) {
    /* ignore */
  }
  el.removeAttribute('src');
  el.load();
}

// Stopping is global, not local: whichever context holds the audio releases it
// when the broadcast arrives, so "Arrêter" from the sidebar also silences the
// detached window (and the other way round).
function stopAudio() {
  playbackGeneration += 1;
  teardownAudio();
  currentStationId = null;
  status = 'stopped';
  playbackOwner = null;
  renderPlaybackState();
  announcePlayback();
}

function renderPlaybackState() {
  const isActive = status === 'playing' || status === 'loading';
  const station = stations.find((item) => item.id === currentStationId);

  document.querySelectorAll('.station').forEach((button) => {
    const active = button.dataset.stationId === currentStationId && isActive;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });

  // The "now playing" bar keeps its reserved height at all times (no layout
  // shift); the "stopped" state shows a discreet empty label via CSS.
  nowplayingNode.setAttribute('data-state', status);

  if (status === 'loading') {
    setActionBadge('...', station ? station.color : '#737373');
    setStatus(station ? 'Connexion à ' + station.name + '…' : 'Connexion…');
    return;
  }

  if (status === 'playing') {
    setActionBadge('ON', station ? station.color : '#2f6b2f');
    setStatus(station ? station.name : '');
    return;
  }

  if (status === 'error') {
    setActionBadge('ERR', '#b3261e');
    setStatus('Flux indisponible.');
    return;
  }

  setActionBadge('', '#737373');
  setStatus('Aucune radio en lecture');
}

function playStation(station) {
  if (status === 'playing' && currentStationId === station.id) {
    stopAudio();
    return;
  }

  startPlayback(station);
}

// Actually (re)connect a station's stream, bypassing the play/stop toggle so it
// can also be used to reconnect the station that is already playing.
function startPlayback(station) {
  playbackGeneration += 1;
  teardownAudio();
  currentStationId = station.id;
  status = 'loading';
  // Claim playback before the stream connects: the announcement makes any other
  // window release its own audio right away, instead of overlapping with ours.
  playbackOwner = CONTEXT_ID;
  renderPlaybackState();
  announcePlayback();

  const el = new Audio(station.streamUrl);
  audio = el;
  el.preload = 'none';
  let usageRecorded = false;

  // All handlers are no-ops once `el` is no longer the current element, so a
  // superseded stream can never drive the UI or re-trigger a stop.
  el.onplaying = () => {
    if (audio !== el) {
      return;
    }
    status = 'playing';
    renderPlaybackState();
    announcePlayback();
    // Count the play once it actually starts, so usage-based ordering reflects
    // real listening. The new order applies on the next refresh/reopen rather
    // than reshuffling tiles mid-playback.
    if (!usageRecorded) {
      usageRecorded = true;
      sendMessage({ type: 'RECORD_USAGE', stationId: station.id }).catch(() => {});
    }
  };
  el.onerror = () => {
    if (audio !== el) {
      return;
    }
    status = 'error';
    renderPlaybackState();
    announcePlayback();
  };
  // A live stream that simply ends (server closed the connection, playlist ran
  // out) fires `ended` — never `error` — and a `pause` we did not trigger means
  // the element stopped on its own. Both leave the UI and the badge stuck on
  // "ON" unless we treat them as a stop.
  el.onended = () => {
    if (audio !== el) {
      return;
    }
    stopAudio();
  };
  el.onpause = () => {
    if (audio !== el) {
      return;
    }
    stopAudio();
  };

  el.play().catch((error) => {
    if (audio !== el) {
      return;
    }
    // A fresh pop-out window may block autoplay (no user gesture yet): don't
    // show a stream error, just return to a clickable state.
    if (error && error.name === 'NotAllowedError') {
      stopAudio();
      return;
    }
    status = 'error';
    renderPlaybackState();
  });
}

function createStationCard(station) {
  const card = document.createElement('div');
  card.className = 'station-card';
  card.style.setProperty('--station-color', station.color);

  if (station.textColor) {
    card.style.setProperty('--station-text', station.textColor);
  }

  const button = document.createElement('button');
  button.className = 'station';
  button.type = 'button';
  button.dataset.stationId = station.id;

  const mark = document.createElement('span');
  mark.className = 'mark';
  mark.textContent = station.mark || station.name;
  mark.setAttribute('aria-hidden', 'true');

  const name = document.createElement('span');
  name.className = 'name';
  name.textContent = station.name;

  button.append(mark, name);
  button.addEventListener('click', () => {
    playStation(station);
  });

  const link = document.createElement('a');
  link.className = 'site-link';
  link.href = station.siteUrl;
  link.target = '_blank';
  link.rel = 'noreferrer noopener';
  link.textContent = 'Site';

  card.append(button, link);
  return card;
}

function renderStations(state) {
  stations = state.stations;
  stationsNode.textContent = '';
  stations.forEach((station) => {
    stationsNode.append(createStationCard(station));
  });
  renderPlaybackState();
}

stopButton.addEventListener('click', () => {
  stopAudio();
});

let refreshing = false;

function refreshStations() {
  if (refreshing) {
    return Promise.resolve();
  }
  refreshing = true;
  refreshButton.classList.add('is-refreshing');

  // Reconnect the current stream too, so refresh also recovers a stalled feed.
  const replayId = (status === 'playing' || status === 'loading') && playbackOwner === CONTEXT_ID
    ? currentStationId
    : null;
  // GET_STATE is async: the user can stop, switch station or hand playback over
  // to another window while it is in flight. Only replay if nothing changed the
  // intent in the meantime, otherwise the refresh would undo their action.
  const replayGeneration = playbackGeneration;
  // Keep the spinner visible long enough to read, even though GET_STATE is instant.
  const minSpin = new Promise((resolve) => setTimeout(resolve, 600));

  return sendMessage({ type: 'GET_STATE' })
    .then(renderStations)
    .then(() => {
      if (replayId && playbackGeneration === replayGeneration) {
        const station = stations.find((item) => item.id === replayId);
        if (station) {
          startPlayback(station);
        }
      }
    })
    .catch(() => {
      setStatus('Impossible de charger les stations.');
    })
    .then(() => minSpin)
    .then(() => {
      refreshing = false;
      refreshButton.classList.remove('is-refreshing');
    });
}

refreshButton.addEventListener('click', refreshStations);

// Pop-out: open the sidebar content in a detached window so the user can close
// the sidebar and keep listening. The current station is handed off via the URL
// and the sidebar's own audio is stopped to avoid playing twice.
function createPopoutWindow() {
  const active = (status === 'playing' || status === 'loading') && currentStationId;
  const handoff = active ? '&station=' + encodeURIComponent(currentStationId) : '';
  const url = api.runtime.getURL('sidebar.html') + '?mode=popout' + handoff;

  // Hand playback over *before* opening the window: releasing our audio after
  // the new window has already connected would broadcast a stop that silences
  // it. The station id travels in the URL, so nothing is lost.
  stopAudio();

  return storageGetLocal('popoutBounds')
    .then((result) => (result && result.popoutBounds) || {})
    .catch(() => ({}))
    .then((bounds) => {
      const opts = { url: url, type: 'popup', width: bounds.width || 380, height: bounds.height || 640 };
      if (typeof bounds.left === 'number') opts.left = bounds.left;
      if (typeof bounds.top === 'number') opts.top = bounds.top;
      return api.windows.create(opts);
    })
    .then((win) => {
      // Remember the window so a second click focuses it instead of stacking a
      // new one; persisted so it survives the sidebar being reopened.
      if (win && typeof win.id === 'number') {
        storageSetLocal({ popoutWindowId: win.id });
      }
    });
}

function openPopout() {
  storageGetLocal('popoutWindowId')
    .then((result) => (result && typeof result.popoutWindowId === 'number') ? result.popoutWindowId : null)
    .catch(() => null)
    .then((existingId) => {
      if (existingId === null || !api.windows || typeof api.windows.update !== 'function') {
        return false;
      }
      // Bring the existing pop-out to the front; rejects if it was closed.
      return api.windows.update(existingId, { focused: true }).then(() => true, () => false);
    })
    .then((focused) => {
      if (!focused) {
        return createPopoutWindow();
      }
    })
    .catch(() => {});
}

popoutButton.addEventListener('click', openPopout);

if (isPopout) {
  document.documentElement.classList.add('popout');
  // No point popping out an already-detached window.
  popoutButton.hidden = true;

  // Remember the window size/position (debounced) to restore it next time.
  let boundsTimer;
  window.addEventListener('resize', () => {
    clearTimeout(boundsTimer);
    boundsTimer = setTimeout(() => {
      storageSetLocal({
        popoutBounds: {
          width: window.outerWidth,
          height: window.outerHeight,
          left: window.screenX,
          top: window.screenY
        }
      });
    }, 600);
  });
}

if (versionNode && api.runtime && typeof api.runtime.getManifest === 'function') {
  versionNode.textContent = 'v' + api.runtime.getManifest().version;
}

function buildChangelog() {
  const fragment = document.createDocumentFragment();

  CHANGELOG.forEach((entry) => {
    const item = document.createElement('section');
    item.className = 'changelog-entry';

    const head = document.createElement('div');
    head.className = 'changelog-entry-head';

    const version = document.createElement('span');
    version.className = 'changelog-version';
    version.textContent = 'v' + entry.version;

    const date = document.createElement('span');
    date.className = 'changelog-date';
    date.textContent = entry.date;

    head.append(version, date);

    const list = document.createElement('ul');
    list.className = 'changelog-list';
    entry.changes.forEach((change) => {
      const line = document.createElement('li');
      line.textContent = change;
      list.append(line);
    });

    item.append(head, list);
    fragment.append(item);
  });

  changelogBody.textContent = '';
  changelogBody.append(fragment);
}

function openChangelog() {
  if (!changelogBody.childNodes.length) {
    buildChangelog();
  }
  changelogOverlay.hidden = false;
  versionNode.setAttribute('aria-expanded', 'true');
  changelogClose.focus();
}

function closeChangelog() {
  if (changelogOverlay.hidden) {
    return;
  }
  changelogOverlay.hidden = true;
  versionNode.setAttribute('aria-expanded', 'false');
  versionNode.focus();
}

versionNode.addEventListener('click', openChangelog);
changelogClose.addEventListener('click', closeChangelog);

// Close on backdrop click (but not when clicking inside the dialog).
changelogOverlay.addEventListener('click', (event) => {
  if (event.target === changelogOverlay) {
    closeChangelog();
  }
});

// Escape closes; Tab is trapped on the close button (only focusable control).
document.addEventListener('keydown', (event) => {
  if (changelogOverlay.hidden) {
    return;
  }
  if (event.key === 'Escape') {
    closeChangelog();
  } else if (event.key === 'Tab') {
    event.preventDefault();
    changelogClose.focus();
  }
});

// Closing the window that holds the audio must not leave the other contexts
// showing a station that is no longer audible. Best effort: the broadcast is
// sent while the page is still alive.
window.addEventListener('pagehide', () => {
  if (playbackOwner === CONTEXT_ID && status !== 'stopped') {
    status = 'stopped';
    currentStationId = null;
    playbackOwner = null;
    announcePlayback();
  }
});

refreshStations().then(() => {
  if (isPopout) {
    const wanted = params.get('station');
    const station = wanted && stations.find((item) => item.id === wanted);
    if (station) {
      playStation(station);
      return;
    }
  }

  // Opened while another context is already playing: adopt its state instead of
  // showing an idle UI (and a badge) that contradicts the sound being heard.
  sendMessage({ type: 'SIDEBAR_PLAYBACK_QUERY', ownerId: CONTEXT_ID }).catch(() => {});
});
